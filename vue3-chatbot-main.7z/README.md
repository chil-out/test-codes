<!-- @format -->

# 1、安装依赖

npm i

# 2、创建.env 文件，并写入环境变量

# 3、执行 crawler.js，爬取 vue3 文档

node ./crawler.js

# 4、执行 langchain.js,将 markdown.md 的数据写入向量数据库中

# 5、开启服务

node ./app.js

## 代理的地址需要自己配置
